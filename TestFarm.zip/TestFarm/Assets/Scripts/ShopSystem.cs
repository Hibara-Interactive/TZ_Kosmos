﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System;

public class ShopSystem : MonoBehaviour
{ //8.5 часов!!!
    ReadPrefs prefs;
    public TextAsset[] asset;
    public GameObject[] priceToBuying;
    public GameObject[] priceToSelling;
    public GameObject tiles;
    public GameObject info;
    public int[] pTS;
    public int[] pTB;
    static int summ;
    void Start()
    {
        summ = 0;
        int pTBid = 0;
        for (int i = 0; i < asset.Length; i++) {
            prefs = ReadPrefs.Load(asset[i]);
            pTB[i] = prefs.price;
            priceToBuying[i].GetComponent<Text>().text = pTB[i].ToString() + " монет/шт";
            if (prefs.pPrice != 0)
            {
                pTS[pTBid] = prefs.pPrice;
                priceToSelling[pTBid].GetComponent<Text>().text = pTS[pTBid].ToString() + " монет/шт";
                pTBid++;
            }
        }

    }

    public void Sale(int id)
    {
        switch (id)
        {
            case 0:
                if (ResourceSystem.egg != 0)
                {
                    summ = pTS[id] * ResourceSystem.egg;
                    ResourceSystem.egg = 0;
                    ResourceSystem.money += summ;
                    ResourceSystem.newUp = true;
					info.transform.GetChild(0).GetComponent<Text>().text = "+ "+summ+" монет(ы)";
					StartCoroutine(Info());
                }
                break;
            case 1:
                if (ResourceSystem.milk != 0)
                {
                    summ = pTS[id] * ResourceSystem.milk;
                    ResourceSystem.milk = 0;
                    ResourceSystem.money += summ;
                    ResourceSystem.newUp = true;
					info.transform.GetChild(0).GetComponent<Text>().text = "+ "+summ+" монет(ы)";
					StartCoroutine(Info());
                }
                break;
        }
		
    }

    public void Buy(int id) //покупка предметов в магазине
    {
        if(ResourceSystem.money>= pTB[id]) { 
        summ = pTB[id];
        TileSelect.idItem = id;
        tiles.GetComponent<TileSelect>().enabled = true;
            info.transform.GetChild(0).GetComponent<Text>().text = "Выберите ячейку для размещения";
            StartCoroutine(Info());
        }
        else
        {
            info.transform.GetChild(0).GetComponent<Text>().text = "Недостаточно монет";
            StartCoroutine(Info());
        }
    }

    public static void MoneyTakeOff()//списание денег, после установки предмета на поле
    {
        ResourceSystem.money -= summ;
        ResourceSystem.newUp = true;
    }

    IEnumerator Info()
    {
        info.GetComponent<Animator>().SetTrigger("open");
        yield return new WaitForSeconds(3);
        info.GetComponent<Animator>().SetTrigger("close");
		yield return new WaitForSeconds(3);
		info.transform.GetChild(0).GetComponent<Text>().text = "";
    }
}

