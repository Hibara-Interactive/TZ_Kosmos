﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;
using UnityEngine.Tilemaps;
using System.IO;


public class TileSelect : MonoBehaviour
{
    public TileBase[] items;
    public GameObject[] farmItems;
    private Tilemap map;
    private Camera mainCamera;
    public static int idItem;
    static bool loadingMap = false;
    public TextAsset asset;

    // Start is called before the first frame update
    void Start()
    {
        map = GetComponent<Tilemap>();
        mainCamera = Camera.main;
        if (!loadingMap)
        {
            CreateMap();
            loadingMap = true;
            gameObject.GetComponent<TileSelect>().enabled = false;
        }

    }

    // Update is called once per frame
    void Update()
    {
         
            if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
        {
            Vector2 clickWorldPosition = mainCamera.ScreenToWorldPoint(Input.GetTouch(0).position);
            AddItem(clickWorldPosition);
        }
    }

    public void AddItem(Vector2 point)
    {
        
        Vector3Int clickCellPosition = map.WorldToCell(point);
        if (clickCellPosition.x >= -4 && clickCellPosition.x <= 3 && clickCellPosition.y >= -4 && clickCellPosition.y <= 3)
        {
            if (map.GetTile(clickCellPosition).name == "ground")
            {
                //int i = Random.Range(0, items.Length);
                map.SetTile(clickCellPosition, items[idItem]);
                GameObject newFarmItem = Instantiate(farmItems[idItem]);
                newFarmItem.transform.position = new Vector2(map.CellToWorld(clickCellPosition).x, map.CellToWorld(clickCellPosition).y + 2.7f);
                ShopSystem.MoneyTakeOff();
                SaveLoad.SaveMap(clickCellPosition.x, clickCellPosition.y, idItem);
            }
        }
        gameObject.GetComponent<TileSelect>().enabled = false;
    }
    public void CreateMap()
    {
        if (!System.IO.File.Exists(Application.persistentDataPath + "/MapResources.xml"))
        {
           SaveLoad.CreateMapResources();
        }
        else
        {

            int x = 0, y = 0, id = 0;
            Debug.Log("Загрузка");
            XmlTextReader reader_node = new XmlTextReader(Application.persistentDataPath + "/MapResources.xml");
            while (reader_node.Read())
            {


                if (reader_node.IsStartElement("Tile"))
                {
                    int.TryParse(reader_node.GetAttribute("XPosition"), out x);

                    int.TryParse(reader_node.GetAttribute("YPosition"), out y);
                    int.TryParse(reader_node.GetAttribute("TileId"), out id);
                    if (id != 0)
                    {
                        
                        Vector3Int clickCellPosition = new Vector3Int(x, y, 0);
                        map.SetTile(clickCellPosition, items[id - 1]);
                        GameObject newFarmItem = Instantiate(farmItems[id - 1]);
                        newFarmItem.transform.position = new Vector2(map.CellToWorld(clickCellPosition).x, map.CellToWorld(clickCellPosition).y + 2.7f);
                    }
                }
            }
        }
        
            
        }

      
    }


