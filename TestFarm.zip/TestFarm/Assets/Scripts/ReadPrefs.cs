﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml.Serialization; //Для работы с файлами формата Xml
using System.IO;

[XmlRoot("Parametrs")] //Указываем корневой контейнер. Работаем с тем что находится внутри <dialogue></dialogue>

public class ReadPrefs
{
    [XmlElement("Id")]
    public int id;

    [XmlElement("Name")]    //Определяет контейнер, с которым работаем
    public string name;     //Выводим значение из контейнера в публичную переменную

    [XmlElement("Price")]
    public int price;

    [XmlElement("EatingTime")]
    public int eTime;

    [XmlElement("LiveTime")]
    public int lTime;

    [XmlElement("ProductPrice")]
    public int pPrice;
    public static ReadPrefs Load (TextAsset _xml)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(ReadPrefs));
        StringReader reader = new StringReader(_xml.text);
        ReadPrefs prefs = serializer.Deserialize(reader) as ReadPrefs;
        return prefs;
    }
}

