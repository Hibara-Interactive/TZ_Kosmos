﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LiveSystem : MonoBehaviour
{
    ReadPrefs prefs;
    int product = 0;
    public TextAsset asset;
    bool live = false;
    bool eating = false;

    void Start()
    {
        prefs = ReadPrefs.Load(asset);        
    }

        

    void Update()
    {

        if (!live)
        {
            startLive();
        }
        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
        {

            var wp = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position);
            var touchPosition = new Vector2(wp.x, wp.y);

            if (GetComponent<BoxCollider2D>() == Physics2D.OverlapPoint(touchPosition))
            {
                switch (prefs.id)
                {
                    case 0:
                        ResourceSystem.wheat+=product;
                        break;
                    case 1:
                        ResourceSystem.egg += product;
                        break;
                    case 2:
                        ResourceSystem.milk += product;
                        break;
                }
                ResourceSystem.newUp = true;
                product =0;
                gameObject.transform.GetChild(0).gameObject.SetActive(false);
                gameObject.GetComponent<BoxCollider2D>().enabled = false;
            }
        }
   }

    public void startLive()
    {
        switch (prefs.id)
        {
            case 0:
                StartCoroutine(Live(prefs.lTime));
                live = true;
                break;
            case 1:
                if (eating)
                {
                    StartCoroutine(Live(prefs.lTime));
                    live = true;
                }
                else if (ResourceSystem.wheat > 0)
                {
                    ResourceSystem.wheat--;
                    StartCoroutine(Live(prefs.lTime));
                    StartCoroutine(Eating(prefs.eTime));
                    live = true;
                    eating = true;
                    ResourceSystem.newUp = true;
                }
                else
                {
                    return;
                }
                break;
            case 2:
                if (ResourceSystem.wheat > 0)
                {
                    ResourceSystem.wheat--;
                    StartCoroutine(Live(prefs.lTime));
                    live = true;
                    ResourceSystem.newUp = true;
                }
                else
                {
                    return;
                }
                break;
        }
    }

    void OnApplicationQuit()
    {
        StopAllCoroutines();
        switch (prefs.id)
        {
            case 0:
                ResourceSystem.wheat += product;
                break;
            case 1:
                ResourceSystem.egg += product;
                break;
            case 2:
                ResourceSystem.milk += product;
                break;
        }

        SaveLoad.SaveResources();
        ResourceSystem.newUp = true;
    }

    IEnumerator Live(int livetime)
    {
        yield return new WaitForSeconds(livetime);
        product++;
        gameObject.transform.GetChild(0).gameObject.SetActive(true);
        gameObject.GetComponent<BoxCollider2D>().enabled = true;
        live = false;
    }

    IEnumerator Eating(int eatingtime)
    {
        yield return new WaitForSeconds(eatingtime);
        eating = false;
    }
    
}

