﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;
using System;

public class SaveLoad : MonoBehaviour
{
    public static void SaveResources()
    {
        XmlElement elem;


        if (!System.IO.File.Exists(Application.persistentDataPath + "/SaveResources.xml"))
        {
            XmlDocument xmlDoc = new XmlDocument();

            XmlNode rootNode = xmlDoc.CreateElement("Resources");
            xmlDoc.AppendChild(rootNode);

            elem = xmlDoc.CreateElement("Money");
            elem.SetAttribute("value", ResourceSystem.money.ToString());
            rootNode.AppendChild(elem);

            elem = xmlDoc.CreateElement("Wheat");
            elem.SetAttribute("value", ResourceSystem.wheat.ToString());
            rootNode.AppendChild(elem);

            elem = xmlDoc.CreateElement("Egg");
            elem.SetAttribute("value", ResourceSystem.egg.ToString());
            rootNode.AppendChild(elem);

            elem = xmlDoc.CreateElement("Milk");
            elem.SetAttribute("value", ResourceSystem.milk.ToString());
            rootNode.AppendChild(elem);

            xmlDoc.Save(Application.persistentDataPath + "/SaveResources.xml");
        }
        else
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(Application.persistentDataPath + "/SaveResources.xml");
            XmlElement rootNode = xmlDoc.DocumentElement;

            foreach (XmlNode node in rootNode.GetElementsByTagName("Money"))
            {
                node.Attributes["value"].Value = ResourceSystem.money.ToString();
            }

            foreach (XmlNode node in rootNode.GetElementsByTagName("Wheat"))
            {
                node.Attributes["value"].Value = ResourceSystem.wheat.ToString();
            }

            foreach (XmlNode node in rootNode.GetElementsByTagName("Egg"))
            {
                node.Attributes["value"].Value = ResourceSystem.egg.ToString();
            }

            foreach (XmlNode node in rootNode.GetElementsByTagName("Milk"))
            {
                node.Attributes["value"].Value = ResourceSystem.milk.ToString();
            }
            xmlDoc.Save(Application.persistentDataPath + "/SaveResources.xml");
        }


    }
    public static void LoadResouces()
    {
        if (!System.IO.File.Exists(Application.persistentDataPath + "/SaveResources.xml"))
        {
            ResourceSystem.money = 100;
            ResourceSystem.wheat = 0;
            ResourceSystem.egg = 0;
            ResourceSystem.milk = 0;
        }
        else
        {
                XmlTextReader reader_scene = new XmlTextReader(Application.persistentDataPath + "/SaveResources.xml");
                while (reader_scene.Read())
                {

                    if (reader_scene.IsStartElement("Money"))
                        int.TryParse(reader_scene.GetAttribute("value"), out ResourceSystem.money);

                    if (reader_scene.IsStartElement("Wheat"))
                        int.TryParse(reader_scene.GetAttribute("value"), out ResourceSystem.wheat);

                    if (reader_scene.IsStartElement("Egg"))
                        int.TryParse(reader_scene.GetAttribute("value"), out ResourceSystem.egg);

                    if (reader_scene.IsStartElement("Milk"))
                        int.TryParse(reader_scene.GetAttribute("value"), out ResourceSystem.milk);

                }
           
            
        }
    }

    public static void SaveMap( int x, int y, int id)
    {
        
        if (System.IO.File.Exists(Application.persistentDataPath + "/MapResources.xml"))
        { 
             XmlDocument xmlDoc = new XmlDocument();
             xmlDoc.Load(Application.persistentDataPath + "/MapResources.xml");
             XmlElement rootNode = xmlDoc.DocumentElement;

             foreach (XmlNode node in rootNode.GetElementsByTagName("Tile"))
             {
                if (Convert.ToInt32(node.Attributes["XPosition"].Value) == x && Convert.ToInt32(node.Attributes["YPosition"].Value) == y)
                {
                    int newId = id + 1;
                    node.Attributes["TileId"].Value = newId.ToString();
                    break;
                }
             }

             xmlDoc.Save(Application.persistentDataPath + "/MapResources.xml");
        }


    }
    
    public static void CreateMapResources()
    {
        XmlElement elem;

        if (!System.IO.File.Exists(Application.persistentDataPath + "/MapResources.xml"))
        {
            XmlDocument xmlDoc = new XmlDocument();
            XmlNode rootNode = xmlDoc.CreateElement("Maps");
            xmlDoc.AppendChild(rootNode);

            for (int i = -4; i < 4; i++)
            {
                for (int j = -4; j < 4; j++)
                {
                    elem = xmlDoc.CreateElement("Tile");
                    elem.SetAttribute("XPosition", i.ToString());
                    elem.SetAttribute("YPosition", j.ToString());
                    elem.SetAttribute("TileId", "0");
                    rootNode.AppendChild(elem);
                }
            }

            xmlDoc.Save(Application.persistentDataPath + "/MapResources.xml");
        }
    }
}


