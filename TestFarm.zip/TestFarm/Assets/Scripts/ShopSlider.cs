﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShopSlider : MonoBehaviour
{
    bool opened = false;
    public void Slide()
    {
        if (!opened)
        {
            GetComponent<Animator>().SetTrigger("open");
            opened = true;
        }
        else
        {
            GetComponent<Animator>().SetTrigger("close");
            opened = false;
        }
    }
}
