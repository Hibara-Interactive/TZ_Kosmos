﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ResourceSystem : MonoBehaviour
{

    public GameObject[] field;
    public GameObject menu;
    public static bool newUp = false;
    public static int money;
    public static int wheat;
    public static int egg;
    public static int milk;

    void Start()
    {
        newUp = false;
        SaveLoad.LoadResouces();
        field[0].GetComponent<Text>().text = money.ToString();
        field[1].GetComponent<Text>().text = wheat.ToString();
        field[2].GetComponent<Text>().text = egg.ToString();
        field[3].GetComponent<Text>().text = milk.ToString();
    }

    void Update()
    {
        if (newUp)
        {   newUp = false;
            AddResources();
            SaveLoad.SaveResources();
            
        }
    }
   
    public void AddResources()
    {
        field[0].GetComponent<Text>().text = money.ToString();
        field[1].GetComponent<Text>().text = wheat.ToString();
        field[2].GetComponent<Text>().text = egg.ToString();
        field[3].GetComponent<Text>().text = milk.ToString();
    }
    public void Menu()
    {
        if (menu.activeSelf)
        {
            menu.SetActive(false);
        }
        else
        {
            menu.SetActive(true);
        }
    }
}

